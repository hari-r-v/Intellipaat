#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Pandas Assignment - 1


# In[ ]:


#You work in XYZ Company as a Python. The company officials want you to build a python program


# In[2]:


#1.Write a function that takes start and end of a range returns a Pandas series object containing
#numbers within that range.
#In case the user does not pass start or end or both they should default to 1 and 10 respectively.
#eg.
 #range_series() -> Should Return a pandas series from 1 to 10
 #range_series(5) -> Should Return a pandas series from 5 to 10
 #range_series(5, 10) -> Should Return a pandas series from 5 to 10


# In[3]:


import pandas as pd
def range_series(a=1,b=10):
    return pd.Series(range(a,b+1))
range_series()


# In[4]:


def range_series(a=5,b=10):
    return pd.Series(range(a,b+1))
range_series()


# In[5]:


def range_series(a=5,b=15):
    return pd.Series(range(a,b+1))
range_series()


# In[6]:


#2.Create a function that takes in two lists named keys and values as arguments.
#Keys would be strings and contain n string values.
#Values would be a list containing n lists.
#The methods should return a new pandas dataframe with keys as column names and values as
#their corresponding values


# In[7]:


def createdataframe(key,value):
    return pd.DataFrame(value,columns=key)
d=createdataframe(["One", "Two"], [["X", "Y"], ["A", "B"]])
print(d)


# In[8]:


#3.Create a function that concatenates two dataframes. Use previously created function to create
#two dataframes and pass them as parameters Make sure that the indexes are reset before
#returning:


# In[9]:


def concat(a,b):
    return pd.concat([a,b],ignore_index=True)
a=createdataframe(["One", "Two"], [["X", "Y"], ["A", "B"]])
b=createdataframe(["One", "Two"], [["F", "S"], ["M", "L"]])
print(concat(a,b))


# In[10]:


#4.Write code to load data from cars.csv into a dataframe and print its details. Details like: 'count',
#'mean', 'std', 'min', '25%', '50%', '75%', 'max'.


# In[11]:


cars= pd.read_csv('cars-4.csv')


# In[12]:


cars


# In[13]:


y=pd.DataFrame(cars)
y


# In[14]:


y.describe()


# In[15]:


#5.Write a method that will take a column name as argument and return the name of the column
#with which the given column has the highest correlation.
#The data to be used is the cars dataset.
#The returned value should not the column named that was passed as the parameters.
#E.G: get_max_correlated_column('mpg') -> should return 'drat' 


# In[16]:


correlation=y.corr()
print(correlation)


# In[17]:


def get_correlate(col):
    correlation=y.corr()
    return correlation[col].sort_values(ascending=False).index[1]
get_correlate("mpg")


# In[ ]:





# In[ ]:




