#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Pandas Assignment - 2


# In[2]:


#You work in XYZ Corporation as a Data Analyst. Your corporation has told you to analyze the
#customer_churn dataset with various functions.
#1. Now select the rows from 20th index till 200th index (exclusive), and columns from 2nd index till
#15th index value.


# In[3]:


import pandas as pd


# In[4]:


data=pd.read_csv('customer_churn.csv')
data


# In[5]:


t=data.iloc[20:201,1:15]


# In[6]:


t


# In[7]:


#Pandas Assignment - 3


# In[8]:


#1.Display the top 100 records from the original data frame.
#2. Display the last 10 records from the data frame.
#3. Display the last record from the data frame.


# In[9]:


top=data.head(100)
top


# In[10]:


last=data.tail(10)
last


# In[11]:


lastr=data.tail(1)
lastr


# In[12]:


#Pandas Assignment - 4


# In[13]:


#1.Now from the churn data frame, try to sort the data by the tenure column according to the
#descending order.


# In[14]:


data.sort_values('tenure',ascending=False)


# In[15]:


#2.Fetch all the records that are satisfying the following condition:
#a. Tenure>50 and the gender as ‘Female’.
#b. Gender as ‘Male’ and SeniorCitizen as 0.
#c. TechSupport as ‘Yes’ and Churn as ‘No’.
#d. Contract type as ‘Month-to-month’ and Churn as‘Yes’.


# In[16]:


data[(data['tenure']>50) & (data['gender']=='Female')]


# In[17]:


data[(data['SeniorCitizen']==0) & (data['gender']=='Male')]


# In[18]:


data[(data['TechSupport']=='Yes') & (data['Churn']=='No')]


# In[19]:


data[(data['Contract']=='Month-to-month') & (data['Churn']=='Yes')]


# In[20]:


#Pandas Assignment - 5


# In[21]:


#1. Use a for loop to calculate the number of customers that are getting the tech support and
#are male senior citizen


# In[22]:


len(data[(data['TechSupport']=='Yes') & (data['gender']=='Male')])


# In[23]:


x=0
for i in range(len(data[(data['TechSupport']=='Yes') & (data['gender']=='Male')])):
    x=x+1


# In[25]:


print(x)


# In[ ]:




